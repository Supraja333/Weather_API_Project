# Weather API Backend (FastAPI)

Simple FastAPI backend that proxies OpenWeatherMap Current Weather API and caches responses in an in-memory LRU cache.

## Requirements
- Python 3.9 or newer
- `git` (optional)
- Recommended: create and use a virtual environment

## Project layout

```
backend/
├── main.py              # FastAPI application entry point
├── requirements.txt     # Python dependencies
├── Readme.md           # This file
└── tests/              # Unit tests directory
    └── test_api.py     # API tests
```

## Installation

1. Create a virtual environment:
   ```bash
   python -m venv venv
   ```

2. Activate the virtual environment:
   ```bash
   venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the API

```bash
python main.py
```

The API will be available at `http://localhost:8000`

## API Documentation

Once running, visit `http://localhost:8000/docs` for interactive Swagger documentation.