// app.js - robust display for the weather frontend

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById('searchForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    await searchWeather();
  });
});

async function searchWeather() {
  const city = document.getElementById('cityInput').value.trim();
  const statusDiv = document.getElementById('status');
  const resultSection = document.getElementById('result');

  if (!city) {
    statusDiv.textContent = 'Please enter a city name.';
    resultSection.classList.add('hidden');
    return;
  }

  statusDiv.textContent = 'Loading...';
  resultSection.classList.add('hidden');

  try {
    const resp = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
    const contentType = resp.headers.get('content-type') || '';

    if (!resp.ok) {
      // try to show vendor detail if available
      if (contentType.includes('application/json')) {
        const err = await resp.json().catch(()=>null);
        const detail = err && err.detail ? JSON.stringify(err.detail) : JSON.stringify(err);
        statusDiv.textContent = `Error ${resp.status}: ${detail}`;
      } else {
        const text = await resp.text().catch(()=>'[no body]');
        statusDiv.textContent = `Error ${resp.status}: ${text}`;
      }
      return;
    }

    const body = await resp.json();
    // body shape: { source: "api"|"cache", data: { curated, raw } } in earlier versions,
    // but current backend returns { source, data } where data is raw (we handle both).
    let curated = null;
    let raw = null;

    if (body.data && body.data.curated) {
      curated = body.data.curated;
      raw = body.data.raw || body.data;
    } else if (body.data && body.data.raw && body.data.curated === undefined) {
      // some versions return { data: { curated, raw } }
      curated = body.data.curated || null;
      raw = body.data.raw || body.data;
    } else if (body.data && body.data.name) {
      // vendor raw returned as body.data
      raw = body.data;
    } else if (body.data && body.data.main) {
      raw = body.data;
    } else if (body.curated) {
      curated = body.curated;
      raw = body.raw || null;
    } else {
      // final fallback: maybe body is the vendor raw
      raw = body.data || body;
    }

    // If curated missing, build a small curated object from raw
    if (!curated && raw) {
      curated = {
        city: raw.name || '--',
        country: raw.sys && raw.sys.country,
        coord: raw.coord,
        weather: (raw.weather && raw.weather[0]) ? {
          main: raw.weather[0].main,
          description: raw.weather[0].description,
          icon: raw.weather[0].icon
        } : null,
        temperature: {
          current: raw.main && raw.main.temp,
          feels_like: raw.main && raw.main.feels_like,
          pressure: raw.main && raw.main.pressure,
          humidity: raw.main && raw.main.humidity,
          temp_min: raw.main && raw.main.temp_min,
          temp_max: raw.main && raw.main.temp_max
        },
        wind: raw.wind || null,
        visibility: raw.visibility,
        sunrise_unix: raw.sys && raw.sys.sunrise,
        sunset_unix: raw.sys && raw.sys.sunset,
        timezone: raw.timezone // seconds offset from UTC
      };
    }

    // Render curated into DOM (with safe fallbacks)
    document.getElementById('cityName').textContent =
      `${curated.city || '--'}${curated.country ? ', ' + curated.country : ''}`;

    document.getElementById('desc').textContent = curated.weather?.description || 'N/A';
    document.getElementById('temp').textContent =
      curated.temperature?.current !== undefined ? `${roundIfNumber(curated.temperature.current)} °C` : '-- °C';
    document.getElementById('feels').textContent =
      curated.temperature?.feels_like !== undefined ? `Feels like: ${roundIfNumber(curated.temperature.feels_like)} °C` : 'Feels like: -- °C';

    document.getElementById('humidity').textContent =
      curated.temperature?.humidity !== undefined ? `${curated.temperature.humidity} %` : '-- %';

    document.getElementById('pressure').textContent =
      curated.temperature?.pressure !== undefined ? `${curated.temperature.pressure} hPa` : '-- hPa';

    document.getElementById('wind').textContent =
      curated.wind && curated.wind.speed !== undefined ? `${curated.wind.speed} m/s${curated.wind.deg ? ' • ' + curated.wind.deg + '°' : ''}` : '--';

    document.getElementById('visibility').textContent =
      curated.visibility !== undefined ? `${curated.visibility} m` : '-- m';

    // Sunrise / Sunset using timezone offset when available
    const tzOffset = curated.timezone !== undefined ? curated.timezone : (raw && raw.timezone) || 0;
    document.getElementById('sunrise').textContent =
      curated.sunrise_unix ? formatUnixWithOffset(curated.sunrise_unix, tzOffset) : '--';
    document.getElementById('sunset').textContent =
      curated.sunset_unix ? formatUnixWithOffset(curated.sunset_unix, tzOffset) : '--';

    // Icon — always use HTTPS to avoid mixed-content blocking
    const iconEl = document.getElementById('icon');
    if (curated.weather && curated.weather.icon) {
      // OpenWeather icon format: https://openweathermap.org/img/wn/{icon}@2x.png
      iconEl.src = `https://openweathermap.org/img/wn/${curated.weather.icon}@2x.png`;
      iconEl.alt = curated.weather.description || 'weather icon';
      iconEl.style.display = 'inline-block';
    } else {
      iconEl.src = '';
      iconEl.alt = '';
      iconEl.style.display = 'none';
    }

    // Put raw vendor response into pre
    const rawObj = raw || body;
    document.getElementById('rawPre').textContent = JSON.stringify(rawObj, null, 2);

    statusDiv.textContent = `Source: ${body.source || 'api'}`;
    resultSection.classList.remove('hidden');

  } catch (err) {
    console.error("Search error:", err);
    document.getElementById('status').textContent = `Error: ${err.message || err}`;
    document.getElementById('result').classList.add('hidden');
  }
}

function roundIfNumber(v) {
  return (typeof v === 'number') ? (Math.round(v * 10) / 10) : v;
}

function formatUnixWithOffset(unixSeconds, offsetSeconds = 0) {
  if (!unixSeconds) return '--';
  // create a Date based on UTC then add offsetSeconds
  const d = new Date((unixSeconds + (offsetSeconds || 0)) * 1000);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
