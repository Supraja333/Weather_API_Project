# main.py - stable, safe, logs requests, clean JSON errors, serves frontend correctly
import os, time, logging
from pathlib import Path
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Logging setup
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("weather-app")

# App
app = FastAPI()

# Paths
BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
INDEX_FILE = PUBLIC_DIR / "index.html"

# Serve static files from /static
if PUBLIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=str(PUBLIC_DIR)), name="static")
    log.info(f"Static files available at /static from: {PUBLIC_DIR}")
else:
    log.warning(f"Public directory not found: {PUBLIC_DIR}")

# Serve index.html at root
@app.get("/")
async def index():
    if INDEX_FILE.exists():
        return FileResponse(str(INDEX_FILE))
    raise HTTPException(status_code=404, detail="index.html not found")


# -----------------------------------------------------------------
# Weather API Setup
# -----------------------------------------------------------------

API_KEY = os.getenv("OPENWEATHER_API_KEY")
if not API_KEY:
    log.warning("OPENWEATHER_API_KEY is NOT set!")

CACHE = {}
CACHE_TTL = 300  # 5 minutes
OPENWEATHER_URL = "https://api.openweathermap.org/data/2.5/weather"


# Log all incoming requests
@app.middleware("http")
async def log_requests(request: Request, call_next):
    log.info(f"Incoming: {request.method} {request.url}")
    response = await call_next(request)
    log.info(f"Completed: {request.method} {request.url} -> {response.status_code}")
    return response


# Core weather fetcher
async def _fetch_weather(city: str):
    if not API_KEY:
        raise HTTPException(status_code=500, detail="Missing OPENWEATHER_API_KEY")

    key = city.strip().lower()

    # Return cached if valid
    if key in CACHE:
        data, ts = CACHE[key]
        if time.time() - ts < CACHE_TTL:
            return {"source": "cache", "data": data}

    # Query vendor
    params = {"q": city.strip(), "appid": API_KEY, "units": "metric"}

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.get(OPENWEATHER_URL, params=params)
    except httpx.RequestError as ex:
        log.error(f"Network error contacting OpenWeather: {ex}")
        raise HTTPException(status_code=502, detail="Unable to contact weather service")

    # Vendor returned non-200 => format clean JSON
    if r.status_code != 200:
        ctype = r.headers.get("content-type", "")
        try:
            vendor_body = r.json()
        except Exception:
            vendor_body = r.text

        log.warning(
            f"Vendor error: status={r.status_code} type={ctype} body={str(vendor_body)[:200]}"
        )

        raise HTTPException(
            status_code=502,
            detail={
                "vendor_status": r.status_code,
                "vendor_body": vendor_body,
                "content_type": ctype,
            },
        )

    # Success
    data = r.json()
    CACHE[key] = (data, time.time())
    return {"source": "api", "data": data}


# Public API route
@app.get("/api/weather")
async def api_weather(city: str):
    return await _fetch_weather(city)


# Fallback route (optional)
@app.get("/weather")
async def weather_fallback(city: str):
    return await _fetch_weather(city)
